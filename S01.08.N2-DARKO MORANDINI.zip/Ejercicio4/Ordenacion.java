package Ejercicio4;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Ordenacion {
    public static void main(String[] args) {
        List<String> lista = Arrays.asList("10", "manzana", "coche", "3", "perro", "20", "40");
    
        Collections.sort(lista, (s1, s2) -> Character.compare(s1.charAt(0), s2.charAt(0)));
        
        lista.forEach(System.out::println);
        
        Collections.sort(lista, Comparator.comparingInt((String s) -> s.contains("e") ? 0 : 1));

        lista.forEach(System.out::println);
        
        lista.replaceAll(s -> s.contains("a") ? s.replace("a", "4") : s);

        lista.forEach(System.out::println);
        
        lista.stream()
        .filter(s -> s.matches("-?\\d+(\\.\\d+)?"))
        .forEach(System.out::println);
    
    }
}
