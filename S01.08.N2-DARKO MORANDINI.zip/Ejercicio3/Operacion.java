package Ejercicio3;

public class Operacion {

	 public static void main(String[] args) {
	        Calculadora suma = (a, b) -> a + b;
	        Calculadora resta = (a, b) -> a - b;
	        Calculadora multiplicacio = (a, b) -> a * b;
	        Calculadora divisio = (a, b) -> a / b;

	        float resultadoSuma = suma.operacio(5, 3);
	        float resultadoResta = resta.operacio(5, 3);
	        float resultadoMultiplicacion = multiplicacio.operacio(5, 3);
	        float resultadoDivision = divisio.operacio(5, 3);

	        System.out.println("Suma: " + resultadoSuma);
	        System.out.println("Resta: " + resultadoResta);
	        System.out.println("Multiplicacion: " + resultadoMultiplicacion);
	        System.out.println("Division: " + resultadoDivision);
	    }
}
