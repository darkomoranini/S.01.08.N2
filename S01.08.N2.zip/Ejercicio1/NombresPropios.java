package Ejercicio1;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class NombresPropios {
    public static void main(String[] args) {
        List<String> nombresPropios = Arrays.asList("Ana", "Alberto", "David", "Eva", "Adam");

        List<String> nombresConA = nombresPropios.stream()
                .filter(nombre -> nombre.startsWith("A"))
                .filter(nombre -> nombre.length() == 3)
                .collect(Collectors.toList());

        System.out.println("Nombres con 'A' y 3 letras: " + nombresConA);
    }
}
