package Ejercicio3;

@FunctionalInterface
public interface Calculadora {

	float operacio(float a, float b);
	
}
